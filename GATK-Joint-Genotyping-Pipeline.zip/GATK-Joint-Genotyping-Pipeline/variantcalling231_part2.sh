#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8G
#SBATCH --time=2-00:00:00     # 2 days
#SBATCH --output=my.stdout.231
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="VariantCalling231"
#SBATCH -p batch # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

# Load modules
module load gatk/4.0.1.2

# Save variables for picard and gatk
export GATK_HOME=/opt/linux/centos/7.x/x86_64/pkgs/gatk/4.0.1.2/gatk
export fa_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.fasta
export snp_file=/rhome/agottscho/bigdata/Paul/RNAseq/outputALL/output.all.filtered.bisnps.vcf
export threads=32

# Change directory to RNAseq directory, make output directory
cd /rhome/agottscho/bigdata/Paul/RNAseq/output231

# Variant Calling using Haplotype Caller.
$GATK_HOME --java-options "-Xmx8g" HaplotypeCaller  \
           -R $fa_file \
           -I splitNCigar.bam \
           -O output.231.g.vcf.gz \
           --dont-use-soft-clipped-bases true \
           -new-qual true \
           --native-pair-hmm-threads $threads \
           -L $snp_file \
           -ip 100 \
           -ERC GVCF


