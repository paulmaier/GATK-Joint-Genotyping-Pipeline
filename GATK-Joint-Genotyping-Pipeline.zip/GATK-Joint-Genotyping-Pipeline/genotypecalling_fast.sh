#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem-per-cpu=16G
#SBATCH --time=2-00:00:00     # 2 days
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="GenotypeSNPs_test"
#SBATCH -p batch # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

# Load modules
module load gatk/4.0.1.2
module load samtools/1.6
module load vcftools
module load bedtools/2.26.0
module load picard/2.14.1

# Save variables for picard and gatk
export GATK_HOME=/opt/linux/centos/7.x/x86_64/pkgs/gatk/4.0.1.2/gatk
export TABIX_HOME=/opt/linux/centos/7.x/x86_64/pkgs/htslib/1.6/bin/tabix
export VCFTOOLS_HOME=/opt/linux/centos/7.x/x86_64/pkgs/vcftools/0.1.15/bin/vcftools
export BEDTOOLS_HOME=/opt/linux/centos/7.x/x86_64/pkgs/bedtools/2.26.0/bin/bedtools
export BREAKBLOCKS_HOME=/rhome/agottscho/bigdata/Paul/RNAseq/genotype/gvcftools-0.17.0/bin/break_blocks
export SAMTOOLS_HOME=/opt/linux/centos/7.x/x86_64/pkgs/samtools/1.6/bin/samtools
export PICARD_HOME=/opt/linux/centos/7.x/x86_64/pkgs/picard/2.14.1/lib/picard.jar
export VCF2oneInterval=/rhome/agottscho/bigdata/Paul/RNAseq/genotype/VCF2oneInterval.R
export VCF2multiInterval=/rhome/agottscho/bigdata/Paul/RNAseq/genotype/VCF2multiInterval.R
export fa_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.fasta
export fai_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.fasta.fai

# Change directory to RNAseq directory, make output directory
cd /rhome/agottscho/bigdata/Paul/RNAseq/genotype;

# Create bed file (index of contig bp positions)
awk 'BEGIN {FS="\t"}; {print $1 FS "0" FS $2}' $fai_file > fasta.bed;

# Break of GVCF into all positions for chosen contig
$BREAKBLOCKS_HOME --region-file fasta.bed --ref $fa_file < output.229.g.vcf > output.229.all.vcf;
$BREAKBLOCKS_HOME --region-file fasta.bed --ref $fa_file < output.230.g.vcf > output.230.all.vcf;
$BREAKBLOCKS_HOME --region-file fasta.bed --ref $fa_file < output.231.g.vcf > output.231.all.vcf;

# Reduce file size by removing complete list of contigs from these 1 SNP files
pattern="^##contig"
sed "/$pattern/d" output.229.all.vcf > output.229.all.temp.vcf;
sed "/$pattern/d" output.230.all.vcf > output.230.all.temp.vcf;
sed "/$pattern/d" output.231.all.vcf > output.231.all.temp.vcf;
mv output.229.all.temp.vcf output.229.all.vcf
mv output.230.all.temp.vcf output.230.all.vcf
mv output.231.all.temp.vcf output.231.all.vcf

# Reassign SNPs to the same fake interval
Rscript --vanilla $VCF2oneInterval output.229.all.vcf /rhome/agottscho/bigdata/Paul/RNAseq/genotype/ SNPlist_concat.txt; 
Rscript --vanilla $VCF2oneInterval output.230.all.vcf /rhome/agottscho/bigdata/Paul/RNAseq/genotype/ SNPlist_concat.txt; 
Rscript --vanilla $VCF2oneInterval output.231.all.vcf /rhome/agottscho/bigdata/Paul/RNAseq/genotype/ SNPlist_concat.txt; 

# Zip and index VCFs
bgzip output.229.all.oneInterval.vcf;
bgzip output.230.all.oneInterval.vcf;
bgzip output.231.all.oneInterval.vcf;
$TABIX_HOME -p vcf output.229.all.oneInterval.vcf.gz;
$TABIX_HOME -p vcf output.230.all.oneInterval.vcf.gz;
$TABIX_HOME -p vcf output.231.all.oneInterval.vcf.gz;

# Add in sequence dictionary for new fasta
$SAMTOOLS_HOME faidx concat.fa
java -jar $PICARD_HOME CreateSequenceDictionary R=concat.fa O=concat.dict
$GATK_HOME UpdateVCFSequenceDictionary \
     -V output.229.all.oneInterval.vcf.gz \
     -R concat.fa \
     --output output.229.all.oneInterval.fixed.vcf.gz
$GATK_HOME UpdateVCFSequenceDictionary \
     -V output.230.all.oneInterval.vcf.gz \
     -R concat.fa \
     --output output.230.all.oneInterval.fixed.vcf.gz
$GATK_HOME UpdateVCFSequenceDictionary \
     -V output.231.all.oneInterval.vcf.gz \
     -R concat.fa \
     --output output.231.all.oneInterval.fixed.vcf.gz

# Read samples into one database using GenomicsDBImport
$GATK_HOME --java-options "-Xmx4g -Xms4g" GenomicsDBImport \
		   -V output.229.all.oneInterval.fixed.vcf.gz \
		   -V output.230.all.oneInterval.fixed.vcf.gz \
		   -V output.231.all.oneInterval.fixed.vcf.gz \
           --genomicsdb-workspace-path temp_database \
           -L chrom_temp

# Joint genotype samples at SNP positions
$GATK_HOME --java-options "-Xmx4g" GenotypeGVCFs \
   -R concat.fa \
   -V gendb://temp_database \
   -O genotyped.vcf.gz \
   -new-qual \
   --max-alternate-alleles 2

# Return intervals to actual chromosomes and positions
gunzip genotyped.vcf.gz;
Rscript --vanilla $VCF2multiInterval genotyped.vcf /rhome/agottscho/bigdata/Paul/RNAseq/genotype/ SNPlist_concat.txt;

# Select biallelic SNPs only
$GATK_HOME SelectVariants \
           -R concat.fa \
           -V genotyped.multiInterval.vcf \
           --select-type-to-include SNP \
           --restrict-alleles-to BIALLELIC \
           --exclude-filtered \
           -O genotyped.multiInterval.bisnps.vcf




