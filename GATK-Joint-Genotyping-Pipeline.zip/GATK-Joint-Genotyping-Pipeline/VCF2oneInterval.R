#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=T)

VCF2oneInterval <- function(vcf.file, wd, snp.file) {
  # Assigns all chromosomes the same temporary chromosome
  # Assigns all positions sequential order 1-end
  # Outputs new vcf, saves old and new intervals to file
  # Assumes vcf file is not gzipped
  
  #Force all integers to write as such, not scientific notation
  options(scipen=999)
  
  suppressMessages(library(vcfR))
  suppressMessages(library(plyr))
  
  # Get base name of vcf file (w/o .vcf)
  base.name <- gsub("(*).vcf", "\\1", vcf.file)
  
  # Import VCF file
  print("Reading VCF file.")
  setwd(wd)
  vcf <- read.vcfR(vcf.file, verbose = F)
  
  # Read in SNPs reference file
  print("Reading and subsetting SNPs from reference file.")
  snps <- read.table(snp.file, header=T, sep="\t", stringsAsFactors=F)
  
  # Subset to only specified SNP positions
  print("Subsetting to only selected SNP positions.")
  snps.ID <- paste(snps$CHROM, snps$POS, sep=".")
  VCF.ID <- data.frame(vcf@fix[,c("CHROM","POS")])
  VCF.ID <- paste(VCF.ID$CHROM, VCF.ID$POS, sep=".")
  keep.pos <- which(VCF.ID %in% snps.ID)
  vcf@fix <- vcf@fix[keep.pos,]
  vcf@gt <- vcf@gt[keep.pos,]
  
  # Rename chromosomes and positions
  print("Renaming chromosomes and positions.")
  snps <- data.frame(snps.ID, snps)
  VCF.ID <- data.frame(vcf@fix[,c("CHROM","POS")])
  VCF.ID <- paste(VCF.ID$CHROM, VCF.ID$POS, sep=".")
  vcfs <- data.frame(snps.ID=VCF.ID, vcf@fix[,c(1:2)])
  position <- join(vcfs, snps, by="snps.ID", type="inner")
  vcf@fix[,"CHROM"] <- rep("chrom_temp", length(vcf@fix[,"CHROM"]))
  vcf@fix[,"POS"] <- position$NEW
  
  # Reorder to reference (ascending) SNP order
  print("Reordering SNPs to reference order. (Make sure ref SNPs are in ascending order.)")
  vcf@fix <- vcf@fix[order(as.integer(vcf@fix[,"POS"])),]
  vcf@gt <- vcf@gt[order(as.integer(vcf@fix[,"POS"])),]
  
  # Write out edited vcf file
  print("Writing edited VCF file.")
  vcf.file.edited <- paste0(base.name, ".oneInterval.vcf.gz")
  write.vcf(vcf, file = vcf.file.edited)
  system(paste0("gunzip ", vcf.file.edited))
  
  #Revert option
  options(scipen=0)
}

# Test if there are 3 arguments: if not, return an error
if (length(args) != 3) {
  stop("There should be 3 arguments.", call.=FALSE)
}

VCF2oneInterval(args[1], args[2], args[3])


