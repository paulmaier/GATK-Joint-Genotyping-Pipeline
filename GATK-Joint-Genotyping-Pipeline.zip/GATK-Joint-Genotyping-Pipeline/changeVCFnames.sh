module load samtools/1.6
export TABIX_HOME=/opt/linux/centos/7.x/x86_64/pkgs/htslib/1.6/bin/tabix

cd /rhome/agottscho/bigdata/Paul/RNAseq/
mkdir genotype
cd genotype
cp /rhome/agottscho/bigdata/Paul/RNAseq/output231/output.229.g.vcf.gz .
cp /rhome/agottscho/bigdata/Paul/RNAseq/output231/output.230.g.vcf.gz .
cp /rhome/agottscho/bigdata/Paul/RNAseq/output231/output.231.g.vcf.gz .

gunzip ./output.229.g.vcf.gz;
gunzip ./output.230.g.vcf.gz;
gunzip ./output.231.g.vcf.gz;

find ./output.229.g.vcf -type f -exec sed -i 's/sample$/North/g' {} \;
find ./output.230.g.vcf -type f -exec sed -i 's/sample$/South/g' {} \;
find ./output.231.g.vcf -type f -exec sed -i 's/sample$/East/g' {} \;
