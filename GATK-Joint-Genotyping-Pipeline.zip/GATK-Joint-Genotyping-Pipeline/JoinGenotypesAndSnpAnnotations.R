# Read in files
suppressMessages(library(vcfR))
suppressMessages(library(plyr))
setwd("~/Desktop/CH2/Transcriptome/")
vcf <- read.vcfR("transcriptome.SNPs.final.vcf", verbose = F)
vcf.ann <- read.vcfR("transcriptome.SNPs.final.annotated.vcf", verbose = F)
ann.vcf <- read.table("transcriptome.SNPs.annotation.table.txt", header=T, quote="", sep="\t", stringsAsFactors=F, na.strings="-")
annotation <- read.table("trinotate_annotation_report.txt", header=T, quote="", sep="\t", stringsAsFactors=F, na.strings="NA")
variant.rank <- read.table("transcriptome.variant.rank.table.txt", header=T, quote="", sep="\t", stringsAsFactors=F, na.strings="NA")
hydro.table <- read.table("transcriptome.variant.hydrophobicity.table.txt", header=T, quote="", sep="\t", stringsAsFactors=F, na.strings="NA")

# Reformat gene annotations
names(annotation)[which(names(annotation) %in% c("gene_id","transcript_id"))] <- c("CHROM","Transcript")
annotation$sprot_Top_BLASTX_hit <- sub(".*\\^RecName: Full=(.*);\\^.*", "\\1", annotation$sprot_Top_BLASTX_hit)
annotation$sprot_Top_BLASTP_hit <- sub(".*\\^RecName: Full=(.*);\\^.*", "\\1", annotation$sprot_Top_BLASTP_hit)
annotation <- annotation[,-which(names(annotation) %in% c("TrEMBL_Top_BLASTX_hit","TrEMBL_Top_BLASTP_hit","prot_id","prot_coords"))]

# Extract genotypes for all SNPs
geno <- extract.gt(vcf, element="GT", return.alleles=T, convertNA=T)
geno[geno=="."] <- NA

# Extract genotypes for all annotated SNPs
fix.ann <- as.data.frame(vcf.ann@fix)[,c(1,2,4,5)]
geno.ann <- extract.gt(vcf.ann, element="GT", return.alleles=T, convertNA=T)
geno.ann[geno.ann=="."] <- NA
geno.ann <- data.frame(ID=row.names(geno.ann), fix.ann, geno.ann)
row.names(geno.ann) <- seq(1, length(row.names(geno.ann)), 1)

# Extract annotations for all annotated SNPs
ann.vcf$Location <- gsub(":", "_", ann.vcf$Location)
names(ann.vcf)[which(names(ann.vcf)=="Location")] <- "ID"
names(ann.vcf)[which(names(ann.vcf)=="Allele")] <- "ALT"
names(ann.vcf)[which(names(ann.vcf)=="Gene")] <- "CHROM"
names(ann.vcf)[which(names(ann.vcf)=="Feature")] <- "Transcript"
ann.vcf$Transcript <- gsub(".p\\d+", "", ann.vcf$Transcript)
ann.vcf$Impact <- gsub(".*IMPACT=([A-Z]*).*", "\\1", ann.vcf$Extra)
ann.vcf$Distance <- suppressWarnings(as.numeric(gsub(".*DISTANCE=([0-9]*).*", "\\1", ann.vcf$Extra)))
ann.vcf$Strand <- suppressWarnings(as.numeric(gsub(".*STRAND=([-1]*);.*", "\\1", ann.vcf$Extra)))
ann.vcf$REF <- gsub(".*([CATG])/[CATG]$", "\\1", ann.vcf$Uploaded_variation)
ann.vcf$POS <- as.numeric(gsub(".*_([0-9]*)$", "\\1", ann.vcf$ID))
aa <- ann.vcf$Amino_acids
aa.df <- data.frame(aa=aa, 
                    aa1=rep(NA, length(aa)),
                    aa2=rep(NA, length(aa)),
                    Hydrophobicity_delta=rep(NA, length(aa)),
                    Hydrophobicity_category_delta=rep(NA, length(aa)))
aa1 <- gsub("([A-Z])/[A-Z]", "\\1", aa[grep("[A-Z]/[A-Z]", aa)])
aa2 <- gsub("[A-Z]/([A-Z])", "\\1", aa[grep("[A-Z]/[A-Z]", aa)])
h1 <- join(data.frame(AA=aa1), hydro.table)$HI
h2 <- join(data.frame(AA=aa2), hydro.table)$HI
h1.cat <- merge(data.frame(AA=aa1), hydro.table)$Category
h2.cat <- merge(data.frame(AA=aa2), hydro.table)$Category
h <- abs(h1-h2)
h.cat <- h1.cat != h2.cat
aa.df[grep("[A-Z]/[A-Z]", aa),"aa1"] <- aa1
aa.df[grep("[A-Z]/[A-Z]", aa),"aa2"] <- aa2
aa.df[grep("[A-Z]/[A-Z]", aa),"Hydrophobicity_delta"] <- h
aa.df[grep("[A-Z]/[A-Z]", aa),"Hydrophobicity_category_delta"] <- h.cat
ann.vcf$Hydrophobicity_delta <- aa.df$Hydrophobicity_delta
ann.vcf$Hydrophobicity_category_delta <- aa.df$Hydrophobicity_category_delta
ann.vcf <- ann.vcf[,-which(names(ann.vcf)%in%c("Uploaded_variation","Feature_type","Existing_variation","Extra"))]
ann.vcf$Consequence <- factor(ann.vcf$Consequence, ordered=T, levels=variant.rank$name)
ann.vcf$Impact <- factor(ann.vcf$Impact, ordered=T, levels=c("HIGH","MODERATE","LOW","MODIFIER"))
ann.vcf.unique <- with(ann.vcf, ann.vcf[order(ID, Consequence, -Hydrophobicity_delta),])
ann.vcf.unique <- ann.vcf.unique[!duplicated(ann.vcf.unique$ID), ]

# Merge genotypes and SNP annotations
annotated.snps <- join(geno.ann, ann.vcf.unique)
annotated.snps <- annotated.snps[c("ID","CHROM","Transcript","POS","REF","ALT",
                                   "East","North","South","cDNA_position",
                                   "CDS_position","Protein_position",
                                   "Amino_acids","Codons","Hydrophobicity_delta",
                                   "Hydrophobicity_category_delta","Distance",
                                   "Strand","Consequence","Impact")]

## Merge genotype/SNP-annotation matrix with gene-annotations
# First, limit gene-annotation to records with BLASTX hits
annotation.temp <- annotation[!is.na(annotation$sprot_Top_BLASTX_hit),]

# Next, limit gene-annotations to one per transcript
# Choose those with (a) consistent ontologies for blastx and ensembl,
# and (b) annotations with the most complete info (e.g. gene, GO terms, etc.)
annotation.temp$blast_consistency <- annotation.temp$sprot_Top_BLASTX_hit == annotation.temp$sprot_Top_BLASTP_hit
annotation.temp$num_NA_records <- apply(annotation.temp, 1, function(x) sum(is.na(x)))
annotation.temp <- with(annotation.temp, annotation.temp[order(Transcript, -blast_consistency, num_NA_records),])
annotation.temp <- annotation.temp[!duplicated(annotation.temp$Transcript), ]
annotation.temp <- annotation.temp[,-which(names(annotation.temp) %in% c("blast_consistency","num_NA_records"))]

# Rules for merging SNPs with gene annotations are as follows:
# 1. Wherever possible, use the same transcript of the gene
# 2. Elsewhere, if multiple gene annotations exist, prioritize by:
#   a. the most common annotation (gene ascribed to most transcripts), then...
#   b. consistent ontologies for blastx and ensembl, then...
#   c. annotations with the most complete info (e.g. gene, GO terms, etc.)

# 1. Find cases where the annotated SNP/gene have the same transcript
IDs.1 <- which(annotated.snps$Transcript %in% annotation.temp$Transcript)
annotation.1 <- join(annotated.snps[IDs.1,], annotation.temp, by="Transcript")
annotation.1 <- annotation.1[-which(names(annotation.1) %in% c("CHROM"))[2]]

# 2. Find the other cases...
IDs.2 <- which(!(annotated.snps$Transcript %in% annotation.temp$Transcript))
gene_occurrence <- count(annotation.temp,c("CHROM","sprot_Top_BLASTX_hit"))
names(gene_occurrence) <- c("CHROM","sprot_Top_BLASTX_hit","gene_occurrence")
annotation.temp <- join(annotation.temp, gene_occurrence, by=c("CHROM","sprot_Top_BLASTX_hit"))
annotation.temp$blast_consistency <- annotation.temp$sprot_Top_BLASTX_hit == annotation.temp$sprot_Top_BLASTP_hit
annotation.temp$num_NA_records <- apply(annotation.temp, 1, function(x) sum(is.na(x)))
annotation.temp <- with(annotation.temp, annotation.temp[order(CHROM, -gene_occurrence, -blast_consistency, num_NA_records),])
annotation.temp <- annotation.temp[!duplicated(annotation.temp$CHROM), ]
annotation.temp <- annotation.temp[,-which(names(annotation.temp) %in% c("gene_occurrence","blast_consistency","num_NA_records"))]
annotation.2 <- join(annotated.snps[IDs.2,], annotation.temp, by="CHROM")
annotation.2 <- annotation.2[-which(names(annotation.2) %in% c("Transcript"))[2]]

# Final annotation data frame
annotation.final <- rbind(annotation.1, annotation.2)
annotation.final <- annotation.final[,-which(names(annotation.final) %in% c("ID"))]

# Write to file
write.table(annotation.final, "transcriptome.SNPs.genes.final.annotated.txt",
            quote=F, sep="\t", row.names=F)


# Display prevalence of genes using a word cloud
library("tm")
library("SnowballC")
library("wordcloud")
library("RColorBrewer")

word.data <- annotation.final[which(annotation.final$Impact %in% c("HIGH")),]
word.data <- table(word.data$sprot_Top_BLASTX_hit)
word.data <- data.frame(names=names(word.data), genes.freq=as.integer(word.data))
word.data <- word.data[order(-word.data$genes.freq),]
remove <- grepl("polyprotein", word.data$names, ignore.case=T) | 
          grepl("transpos", word.data$names, ignore.case=T) |
          grepl("LINE-1", word.data$names, ignore.case=T) |
          grepl("Protein P", word.data$names, ignore.case=T)
word.data <- word.data[!remove,]

wordcloud(words = word.data$names, freq = word.data$genes.freq, min.freq = 1,
          max.words=2000, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(100, "Dark2"))


