#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=30G
#SBATCH --time=5-00:00:00     # 5 days
#SBATCH --output=my.stdout.ALL
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="VariantCallingALL"
#SBATCH -p highmem # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

# Load modules
module load picard/2.14.1
module load samtools/1.6
module load STAR/2.5.3a
module load gatk/4.0.1.2

# Save variables for picard and gatk
export SAMTOOLS_HOME=/opt/linux/centos/7.x/x86_64/pkgs/samtools/1.6/bin/samtools
export STAR_HOME=/opt/linux/centos/7.x/x86_64/pkgs/STAR/2.5.3a/bin/STAR
export PICARD_HOME=/opt/linux/centos/7.x/x86_64/pkgs/picard/2.14.1/lib/picard.jar
export GATK_HOME=/opt/linux/centos/7.x/x86_64/pkgs/gatk/4.0.1.2/gatk
export fa_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.fasta
export gtf_file=/rhome/agottscho/bigdata/Paul/RNAseq/trinity_genes.gtf
export R1=/rhome/agottscho/bigdata/Paul/RNAseq/R1.fastq.gz
export R2=/rhome/agottscho/bigdata/Paul/RNAseq/R2.fastq.gz
export threads=32
export memory=960000000000
export read_length=100

# Change directory to RNAseq directory, make output directory
cd /rhome/agottscho/bigdata/Paul/RNAseq/
mkdir outputALL
cd outputALL

# Generating SuperTranscript index.
$SAMTOOLS_HOME faidx $fa_file

# Generating Picard dictionary.
java -jar $PICARD_HOME CreateSequenceDictionary R=$fa_file O=trinity_genes.dict

# Generating genome folder for STAR
mkdir star_genome_idx
$STAR_HOME --runThreadN $threads \
           --runMode genomeGenerate \
           --genomeDir star_genome_idx \
           --genomeFastaFiles $fa_file \
           --sjdbGTFfile $gtf_file \
           --sjdbOverhang $read_length \
           --limitGenomeGenerateRAM $memory

# Running STAR alignment.
$STAR_HOME --runThreadN $threads \
           --genomeDir star_genome_idx \
           --runMode alignReads \
           --twopassMode Basic \
           --alignSJDBoverhangMin 10 \
           --outSAMtype BAM SortedByCoordinate \
           --limitBAMsortRAM $memory \
           --readFilesIn $R1 $R2 \
           --readFilesCommand gunzip -c

# Assign all reads to a single new read group in the OUTPUT BAM file.
java -jar $PICARD_HOME AddOrReplaceReadGroups I=Aligned.sortedByCoord.out.bam O=rg_added_sorted.bam SO=coordinate \
                       RGID=id RGLB=library RGPL=platform RGPU=machine RGSM=sample

# Identify duplicate reads.
java -jar $PICARD_HOME MarkDuplicates I=rg_added_sorted.bam O=dedupped.bam CREATE_INDEX=true \
                       VALIDATION_STRINGENCY=SILENT M=output.metrics
                   
# Splits reads that contain Ns in their CIGAR string    
$GATK_HOME SplitNCigarReads \
           -R $fa_file \
           -I dedupped.bam \
           -O splitNCigar.bam


