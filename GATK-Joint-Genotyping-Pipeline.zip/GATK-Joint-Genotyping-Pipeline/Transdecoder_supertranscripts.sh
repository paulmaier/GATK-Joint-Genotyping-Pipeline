#!/bin/bash -l

#SBATCH --nodes=1
#SBATCH --ntasks=32
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=8G
#SBATCH --time=1-00:00:00     # 1 day
#SBATCH --output=my.stdout.Transdecoder
#SBATCH --mail-user=maierpa@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --job-name="Transdecoder"
#SBATCH -p batch # This is the default partition, you can use any of the following; intel, batch, highmem, gpu

module load transdecoder
module load trinity-rnaseq

cd /rhome/agottscho/bigdata/Paul/RNAseq/

# convert to gff3 alignment format
gtf_to_alignment_gff3.pl trinity_genes.gtf > trinity_genes.gff3

# extract the transcript sequences
gtf_genome_to_cdna_fasta.pl trinity_genes.gtf trinity_genes.fasta > trinity_transcripts.fasta

# run TransDecoder
TransDecoder.LongOrfs -t trinity_transcripts.fasta

TransDecoder.Predict -t trinity_transcripts.fasta

# propagate predicted ORFs to the supertranscript gff3 file:
cdna_alignment_orf_to_genome_orf.pl trinity_transcripts.fasta.transdecoder.gff3 trinity_genes.gff3 trinity_transcripts.fasta > supertranscripts.wOrfs.gff3

# make bed file for visualization
gff3_file_to_bed.pl supertranscripts.wOrfs.gff3 > supertranscripts.wOrfs.bed

# convert to gtf as companion to the gff3 file (some other tools prefer gtf format)
~/bigdata/Paul/RNAseq/TransDecoder-devel/util/gff3_gene_to_gtf_format.pl \
supertranscripts.wOrfs.gff3 trinity_genes.fasta > supertranscripts.wOrfs.gtf